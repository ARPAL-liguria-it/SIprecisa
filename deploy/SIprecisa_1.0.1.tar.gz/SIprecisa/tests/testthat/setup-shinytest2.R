# Load application support files into testing environment
# if (FALSE) shinytest2::load_app_env()
# as suggested in https://github.com/rstudio/shinytest2/issues/271
